<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","root","phonegap_demo") or die ("could not connect database");
?>